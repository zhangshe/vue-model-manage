﻿window.onload = function () {

    var xmlHttp;
    // Create the XHR object.
    function createCORSRequest(method, url) {
        var xhr = new XMLHttpRequest();
        if ("withCredentials" in xhr) {
            // XHR for Chrome/Firefox/Opera/Safari.
            xhr.open(method, url, true);
        } else if (typeof XDomainRequest != "undefined") {
            // XDomainRequest for IE.
            xhr = new XDomainRequest();
            xhr.open(method, url);
        } else {
            // CORS not supported.
            xhr = null;
        }
        if (method == "POST") {
            xhr.setRequestHeader("Accept", "application/json");
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
        }
        return xhr;
    }

    // Helper method to parse the title tag from the response.
    function getTitle(text) {
        return text.match('<title>(.*)?</title>')[1];
    }


    // Make the actual CORS request.
    function makeCorsRequest(url) {
        // All HTML5 Rocks properties support CORS.

      
    }

    var null2str = function (data) {
        if (data == null || data == 'null') {
            return "";
        } else { return data; }
    };


    document.getElementById("load").addEventListener("click", function () {
        
        xmlHttp = createCORSRequest('POST', 'http://192.168.144.24/prod-api/FMUModel/Authentication', true);
        //xmlHttp.onreadystatechange = callback;
        if (!xmlHttp) {
            alert('CORS not supported');
            return;
        }


  
        var formData = new URLSearchParams();
        formData.append('ModelGUID','{6b5ac401-c9c0-49e8-ae18-91a469bb0286}')
        formData.append('Invoker','管理员')
        formData.append('OrgName','基础研究部')
        formData.append('DeptName','前瞻技术研究室')
        xmlHttp.send(formData);
        // Response handlers.
        xmlHttp.onload = function () {
            if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                                //请求成功后执行的代码
                                var fmu_id = document.getElementById("guid").value;

                                if (!fmu_id) { return; }
                
                                var rpc_address = document.getElementById("rpc").value;
                
                                var transport = new Thrift.TXHRTransport(rpc_address);
                                var protocol = new Thrift.TJSONProtocol(transport);
                                var client = new FmuServiceClient(protocol);
                
                                var model_description = client.get_model_description(fmu_id);
                
                                //模型基本信息
                                for (let prop in model_description) {
                                    var _dom = document.getElementById("model_description." + prop);
                                    if (_dom != null) {
                                        _dom.innerHTML = model_description[prop];
                
                                    }
                                }
                
                                //默认实验信息
                                for (let prop in model_description.default_experiment) {
                                    var _dom = document.getElementById("model_description.default_experiment." + prop);
                                    if (_dom != null) {
                                        _dom.value = model_description.default_experiment[prop];
                                    }
                                }
                
                                //属性列表
                                document.getElementById("model_description.model_variables").innerHTML = "";
                
                                model_description.model_variables.sort(function (a, b) {
                                    return b.value_reference - a.value_reference;
                                });
                
                                var typeTest = function (obj) {
                                    if (obj.integer_attribute != null) { return "integer"; }
                                    else if (obj.real_attribute != null) { return "real"; }
                                    else if (obj.string_attribute != null) { return "string"; }
                                    else if (obj.boolean_attribute != null) { return "boolean"; }
                                    else if (obj.enumeration_attribute != null) { return "enumeration"; }
                                    else { return "-"; }
                                };
                
                                var input_params = new Array();
                                var output_params = new Array();
                                for (let i = 0; i < model_description.model_variables.length; i++) {
                                    var _var = model_description.model_variables[i];
                                    var attr_type = typeTest(_var.attribute);
                                    var objE = document.createElement("tr");
                                    objE.innerHTML = "<tr><td>" + _var.name + "</td>" +
                                        "<td>" + null2str(_var.value_reference) + "</td>" +
                                        "<td>" + null2str(_var.description) + "</td>" +
                                        "<td>" + null2str(_var.causality) + "</td>" +
                                        "<td>" + null2str(_var.initial) + "</td>" +
                                        "<td>" + null2str(_var.variability) + "</td>" +
                                        "<td>" + attr_type + "</td>";
                                    if (_var.causality == "input") {
                                        var _onj = {};
                                        _onj.index = _var.value_reference;
                                        _onj.name = _var.name;
                                        _onj.type = attr_type;
                                        input_params.push(_onj);
                                        objE.innerHTML += "<td><input id='" + _var.value_reference + "' value='" + 1 + "'/></td></tr>";
                                    }
                                    else if (_var.causality == "output") {
                                        var _onj = {};
                                        _onj.index = _var.value_reference;
                                        _onj.name = _var.name;
                                        _onj.type = attr_type;
                                        output_params.push(_onj);
                                        objE.innerHTML += "<td>-</td></tr>";
                                    }
                                    else {
                                        objE.innerHTML += "<td>-</td></tr>";
                                    }
                
                                    document.getElementById("model_description.model_variables").insertBefore(objE, document.getElementById("model_description.model_variables").childNodes[0]);
                
                
                                    document.getElementById("calc").addEventListener("click", function () {
                
                                        document.getElementById("msg").value = "";
                
                                        try {
                                            var instance_id = client.create_instance(fmu_id);
                                            var start = document.getElementById("model_description.default_experiment.startTime").value;
                                            var stop = document.getElementById("model_description.default_experiment.stopTime").value;
                                            var tolerance = document.getElementById("model_description.default_experiment.tolerance").value;
                                            var step_size = document.getElementById("model_description.default_experiment.stepSize").value;
                
                                            status = client.setup_experiment(instance_id, start, stop, tolerance);
                                            status = client.enter_initialization_mode(instance_id);
                                            status = client.exit_initialization_mode(instance_id);
                
                                            var status = null;
                                            var t = start;
                
                                            for (var __i in input_params) {
                                                var _i = input_params[__i];
                                                var _v = document.getElementById(_i.index.toString()).value;
                                                if (_i.type == "integer") { client.write_integer(instance_id, [_i.index], [_v]); }
                                                else if (_i.type == "real") { client.write_real(instance_id, [_i.index], [_v]); }
                                                else if (_i.type == "string") { client.write_string(instance_id, [_i.index], [_v]); }
                                                else if (_i.type == "boolean") { client.write_boolean(instance_id, [_i.index], [_v.toLowerCase() == "true"]); }
                                                else if (_i.type == "enumeration") { client.write_integer(instance_id, [_i.index], [_v]); }
                                            }
                
                                            if (step_size == 0) { step_size = 1; }
                
                                            var t0 = performance.now();
                
                                            var counter = 0;
                
                                            while (t < stop) {
                
                                                if (counter++ > 1000) {
                                                    document.getElementById("msg").value += "测试计算演示仅计算不超过1000步.\r\n";
                                                    break;
                                                }
                
                                                var _text = "step=" + t + ":  ";
                
                
                                                for (var __i in output_params) {
                                                    var _i = output_params[__i];
                                                    _text += _i.name + "=";
                                                    var _v = null;
                                                    if (_i.type == "integer") { _v = client.read_integer(instance_id, [_i.index]); }
                                                    else if (_i.type == "real") { _v = client.read_real(instance_id, [_i.index]); }
                                                    else if (_i.type == "string") { _v = client.read_string(instance_id, [_i.index]); }
                                                    else if (_i.type == "boolean") { _v = client.read_boolean(instance_id, [_i.index]); }
                                                    else if (_i.type == "enumeration") { _v = client.read_integer(instance_id, [_i.index]); }
                                                    _text += _v.value + " ,"
                
                                                }
                
                                                _text = _text.substring(0, _text.length - 1);
                
                
                                                _text = _text + "\r\n";
                
                                                document.getElementById("msg").value += _text;
                
                                                var result = client.step(instance_id, step_size);
                                                if (result.status != 0) {
                                                    document.getElementById("msg").value += "Step failed!\r\n";
                                                    break
                                                }
                                                t = result.simulation_time
                
                                            }
                
                                            var t1 = performance.now()
                
                                            document.getElementById("msg").value += "用时:" + (t1 - t0) + " ms.\r\n";
                                            status = client.terminate(instance_id)
                
                                        } catch (err) {
                                            document.getElementById("msg").value = err.message;
                                        }
                
                
                                    });
                
                                }
                
            }
        };

        xmlHttp.onerror = function () {
            alert('Woops, there was an error making the request.');
        };
        

    });

   

};