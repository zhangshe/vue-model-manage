from flask_api import status
from flask import Flask, request
from flask_restplus import Api, Resource, fields,reqparse

app = Flask(__name__)
app.config.from_object('config')
app.config['RESTPLUS_MASK_SWAGGER'] = False
app.config['RESTPLUS_VALIDATE'] = False
app.config['JSON_AS_ASCII'] = False
app.config.update(RESTFUL_JSON=dict(ensure_ascii=False))
base_url = app.config.get("BASE_URL")
host = app.config.get("HOST")
port = app.config.get("PORT")
environment = app.config.get("ENV")
debug = app.config.get("DEBUG")

api = Api(app,
          version=app.config.get("SWAGGER_API_VERSION"),
          title=app.config.get("SWAGGER_TITLE"),
          description=app.config.get("SWAGGER_DESCRIPTION"),
          doc="/api-docs",
          payload="body",
          contact="honeycomb",
          contact_url="www.honeycombtech.com",
          contact_email="admin@honeycombtech.com")

# NameSpaces
apiService = api.namespace('apiService', description="非标机理模型处理服务", path="/")

# 字符串类型参数前要加个u防止swagger页面展示默认值中双引号异常
# TODO
# .add_argument('input', required=True, location='json', default={'val1': u'参数1', 'val2': u'参数2'})

parser = reqparse.RequestParser()                      # 参数模型
parser.add_argument('val1', type=str, required=True, help="val1")
parser.add_argument('val2', type=str, required=True, help="val2")


@apiService.route('/api/service')
class _ApiService(Resource):
    @apiService.doc(description="Sub方法")
    @apiService.expect(parser)
    def get(self):
        if request.method == 'GET':
            val1 = request.args.get('val1')
            val2 = request.args.get('val2')
            val3 = float(val1) + float(val2)
            return str(val3), status.HTTP_200_OK
        else:
            return  status.HTTP_400_BAD_REQUEST

if __name__ == '__main__':
    app.run(debug=debug, threaded=True, host=host, port=port)
